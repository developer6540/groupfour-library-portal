import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET);
const IS_PROD = process.env.NODE_ENV === "production";

export async function proxy(req: NextRequest) {

    const { pathname } = req.nextUrl;

    const token = req.cookies.get("auth-session")?.value;
    const csrfCookie = req.cookies.get("X-CSRF-Token")?.value;

    const isApiRequest = pathname.startsWith("/api/");
    const isWriteMethod = ["POST", "PUT", "DELETE", "PATCH"].includes(req.method);

    const publicRoutes = [
        "/sign-in",
        "/register",
        "/forgot-password",
        "/payment",
        "/api/v1/auth/login",
        "/api/v1/auth/register",
        "/api/v1/locations",
        "/api/v1/payment",
    ];

    const isPublicRoute = publicRoutes.some(route => pathname.startsWith(route));

    // Create response early so we can attach cookies
    const response = NextResponse.next();

    // Ensure CSRF Cookie Exists
    if (!csrfCookie) {
        response.cookies.set("X-CSRF-Token", crypto.randomUUID(), {
            path: "/",
            httpOnly: false,
            secure: IS_PROD,   // only enforce Secure flag in production (HTTPS)
            sameSite: "lax",
        });
    }

    // Redirect logged-in users away from sign-in
    if (pathname === "/sign-in" && token) {
        try {
            await jwtVerify(token, JWT_SECRET);
            return NextResponse.redirect(new URL("/", req.url));
        } catch {}
    }

    // CSRF Validation
    if (isApiRequest && isWriteMethod) {
        const headerToken = req.headers.get("X-CSRF-Token");
        if (!headerToken || !csrfCookie || headerToken !== csrfCookie) {
            console.log("CSRF Not Allowed");
            return NextResponse.json(
                { message: "Unauthorized Access" },
                { status: 401 }
            );
        }
    }

    // Auth Protection
    if (!token && !isPublicRoute) {
        if (isApiRequest) {
            console.log("Token Not Allowed");
            return NextResponse.json(
                { message: "Unauthorized Access" },
                { status: 401 }
            );
        }

        return NextResponse.redirect(new URL("/sign-in", req.url));
    }

    // Verify JWT
    if (token && !isPublicRoute) {
        try {
            await jwtVerify(token, JWT_SECRET);
        } catch {
            const redirect = NextResponse.redirect(new URL("/sign-in", req.url));
            redirect.cookies.delete("auth-session");
            return redirect;
        }
    }

    return response;
}

export const config = {
    matcher: [
        // Run middleware on all routes except static files
        "/((?!_next/static|_next/image|favicon.ico|img|vdo).*)",
    ],
};